﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MultiProcesses.Common;
using Newtonsoft.Json;

namespace MultiProcesses.Server
{
    class Server
    {


        /*
         *  https://stackoverflow.com/questions/34130323/deserializing-data-from-a-network-stream-hangs-using-newtonsoft-json
         *
         *
         *
         * https://stackoverflow.com/questions/8157636/can-json-net-serialize-deserialize-to-from-a-stream/22689976
         * https://github.com/JamesNK/Newtonsoft.Json/issues/645
         * https://github.com/JamesNK/Newtonsoft.Json/issues/732
         * https://stackoverflow.com/questions/6958255/what-are-some-reasons-networkstream-read-would-hang-block
         * https://github.com/JamesNK/Newtonsoft.Json/issues/732
         */
        static void Main(string[] args)
        {
            EnvironmentVars.ProcessType = EnvironmentVars.Server;
            // int port = Int32.Parse(args[0]);
            int port = 60110;

            Logger.Write($"Started with port {port}");

            try
            {
                var listener = StartListening(port);

                bool connected = true;
                while (connected)
                {
                    Socket client = listener.Accept();
                    Logger.Write($"Accepted client on {client.RemoteEndPoint}");


                    Console.WriteLine();
                    Logger.Write("Read next data...");
                    int bytesRead;
                    Data[] data = ReceiveJson(client, out bytesRead);
                    Logger.Write($"Data received : '{data.Length:N0} items, {bytesRead:N0} bytes, ids from {data[0].Id} to {data.Last().Id:N0}'");

                    /*
                                        var str = ReceiveWithStreamReader(client);
                                        Console.WriteLine($"{str.Length} chars recieved");
                    */

                    byte[] bytes = BitConverter.GetBytes(bytesRead);
                    client.Send(bytes);

                    Thread.Sleep(1000);

                    client.Close();
                }
            }
            catch (Exception e)
            {
                Logger.Write($"Exception: {e}");
                Console.WriteLine("Press any key to exit...");
                Console.ReadKey();
            }

            Console.WriteLine("\nCompleted successfully");
        }

        private static Data[] ReceiveJson(Socket client, out int bytesRead)
        {
            // An incoming connection needs to be processed.  
            // https://docs.microsoft.com/en-us/dotnet/api/system.net.sockets.networkstream?redirectedfrom=MSDN&view=netframework-4.8


            using (var networkStream = new NetworkStream(client))
            {
                using(var noMoreDataAwareStream = new NoMoreDataStream(networkStream))
                using (var streamReader = new StreamReader(noMoreDataAwareStream))
                using (var jsonTextReader = new JsonTextReader(streamReader))
                {
                    var serializer = new JsonSerializer();
                    Logger.Write($"Start deserializing...");
                    var data = serializer.Deserialize<Data[]>(jsonTextReader);
                    Logger.Write($"Deserializing completed. {noMoreDataAwareStream.BytesRead:N0} bytes read");

                    bytesRead = noMoreDataAwareStream.BytesRead;
                    return data;
                }
            }
        }

        private static string ReceiveWithStreamReader(Socket client)
        {
            StringBuilder builder = new StringBuilder();
            // An incoming connection needs to be processed.  
            // https://docs.microsoft.com/en-us/dotnet/api/system.net.sockets.networkstream?redirectedfrom=MSDN&view=netframework-4.8
            using (var networkStream = new NetworkStream(client))
            {
                using (var streamReader = new StreamReader(networkStream))
                {
/*
                    char[] buffer = new char[10];
                    int bytesRead;
                    while ((bytesRead = sr.Read(buffer, 0, buffer.Length)) != 0)
                    {
                        builder.Append(buffer, 0, bytesRead);
                        buffer = new char[10];
                        var da = networkStream.DataAvailable;
                    }

                    var str = builder.ToString();
                    return str;
*/


                    string str = streamReader.ReadLine();
                    return str;

                }
            }
        }

        private static string ReceiveData3(Socket client)
        {
            StringBuilder builder = new StringBuilder();
            // An incoming connection needs to be processed.  
            // https://docs.microsoft.com/en-us/dotnet/api/system.net.sockets.networkstream?redirectedfrom=MSDN&view=netframework-4.8
            using (var networkStream = new NetworkStream(client))
            {
                byte[] buffer = new byte[10];
                int bytesRead;
                while ((bytesRead = networkStream.Read(buffer, 0, buffer.Length)) != 0)
                {
                    string stringData = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                    builder.Append(stringData);
                    buffer = new byte[10];
                }

                var str = builder.ToString();
                return str;
            }
        }

        private static void SendResponse(Socket client)
        {
            // Echo the data back to the client.  
            byte[] msg = Encoding.ASCII.GetBytes(_data);

            client.Send(msg);
            client.Shutdown(SocketShutdown.Both);
            client.Close();
        }

        public static void ReceiveData(int port)
        {
            



        }

        #region Socket routines

        public static Socket AcceptConnection(Socket listener)
        {
            // Logger.Write($"Waiting for a connection on port {port}");
            // Program is suspended while waiting for an incoming connection.  
            Socket client = listener.Accept();
            return client;
        }

        private static Socket StartListening(int port)
        {
// Establish the local endpoint for the socket.  
            // Dns.GetHostName returns the name of the   
            // host running the application.  
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[0];
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, port);

            // Create a TCP/IP socket.  
            Socket listener = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            // Bind the socket to the local endpoint and   
            // listen for incoming connections.  
            listener.Bind(localEndPoint);
            listener.Listen(10);
            return listener;
        }

        #endregion


        /////////////////////////////////////////////////////////////////////

        // Incoming data from the client.  
        public static string _data = null;

        public static void StartListening()
        {
            // Data buffer for incoming data.  
            byte[] bytes = new Byte[1024];

            // Establish the local endpoint for the socket.  
            // Dns.GetHostName returns the name of the   
            // host running the application.  
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[0];
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 11000);

            // Create a TCP/IP socket.  
            Socket listener = new Socket(ipAddress.AddressFamily,
                SocketType.Stream, ProtocolType.Tcp);

            // Bind the socket to the local endpoint and   
            // listen for incoming connections.  
            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(10);

                // Start listening for connections.  
                while (true)
                {
                    Logger.Write($"Waiting for a connection...");
                    // Program is suspended while waiting for an incoming connection.  
                    Socket handler = listener.Accept();
                    _data = null;

                    // An incoming connection needs to be processed.  
                    while (true)
                    {
                        int bytesRec = handler.Receive(bytes);
                        _data += Encoding.ASCII.GetString(bytes, 0, bytesRec);
                        if (_data.IndexOf("<EOF>") > -1)
                        {
                            break;
                        }
                    }

                    // Show the data on the console.  
                    Logger.Write($"Text received : {_data}");

                    // Echo the data back to the client.  
                    byte[] msg = Encoding.ASCII.GetBytes(_data);

                    handler.Send(msg);
                    handler.Shutdown(SocketShutdown.Both);
                    handler.Close();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("\nPress ENTER to continue...");
            Console.Read();

        }
    }
}
