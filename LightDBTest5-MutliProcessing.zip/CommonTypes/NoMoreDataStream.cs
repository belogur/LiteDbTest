﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;

namespace MultiProcesses.Common
{
    public class NoMoreDataStream : Stream
    {
        private Stream _stream;

        public int _bytesRead;
        public int _bytesWritten;

        public NoMoreDataStream(Stream stream)
        {
            _stream = stream;
        }

        public int BytesRead => _bytesRead;

        public int BytesWritten => _bytesWritten;

        public override void Flush()
        {
            _stream.Flush();
            Log($"bytes {_bytesWritten} written");
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            return _stream.Seek(offset, origin);
        }

        public override void SetLength(long value)
        {
            _stream.SetLength(value);
        }

        private bool _endOfStream;
        private static int _readCallsCount = 0;
        public /*override*/ int Read_Save(byte[] buffer, int offset, int count)
        {
            ++_readCallsCount;

            Log($"enter: prev bytesRead {_bytesRead}, count {count}");
            if (_endOfStream)
            {
                Log("read when endOfStream is TRUE");
                return 0;
            }

            int bytesRead = _stream.Read(buffer, offset, count);

            if (bytesRead == 0)
            {
                Log("read ZERO bytes");
                return 0;
            }
            Log($"read {bytesRead} bytesRead");

            if (buffer[offset + bytesRead - 1] == 0)
            {
                var lastBuf = buffer.Skip(Math.Max(offset + bytesRead - 50, 0)).ToArray();
                Log("read when endOfStream is TRUE");
               _endOfStream = true;
            }

            _bytesRead += bytesRead;
            return bytesRead;
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            ++_readCallsCount;

            Log($"enter: prev bytesRead {_bytesRead}, count {count}");

            int bytesRead = _stream.Read(buffer, offset, count);

            if (bytesRead == 0)
            {
                Log("read ZERO bytes");
                return 0;
            }
            Log($"read {bytesRead} bytesRead");

            if (buffer[offset + bytesRead - 1] == 0)
            {
                var lastBuf = buffer.Skip(Math.Max(offset + bytesRead - 50, 0)).ToArray();
                Log("read when endOfStream is TRUE");
               _endOfStream = true;
            }

            _bytesRead += bytesRead;
            return bytesRead;
        }

        private static int _writeCallsCount = 0; 
        public override void Write(byte[] buffer, int offset, int count)
        {
            _writeCallsCount++;
            _bytesWritten += count;
            _stream.Write(buffer, offset, count);
            Log($"{count} written");
        }

        public override bool CanRead
        {
            get { return _stream.CanRead; }
        }

        public override bool CanSeek
        {
            get { return _stream.CanSeek; }
        }
        public override bool CanWrite
        {
            get { return _stream.CanWrite; }
        }

        public override long Length
        {
            get { return _stream.Length; }
        }

        public override long Position
        {
            get { return _stream.Position; }
            set { _stream.Position = value; }
        }

        void Log(string msg = null)
        {
            StackFrame frame = new StackFrame(1);
            var method = frame.GetMethod().Name;

            StringBuilder builder = new StringBuilder();
            builder
                .Append($"Stream_0x{GetHashCode():X8}")
                .Append($"::{method}");
            if (method == nameof(Read))
                builder.Append($" ({_readCallsCount})");
            else if (method == nameof(Write))
                builder.Append($" ({_writeCallsCount})");

            if (msg != null)
                builder
                    .Append(": ")
                    .Append(msg);

            // Logger.Write(builder.ToString());
        }
    }
}