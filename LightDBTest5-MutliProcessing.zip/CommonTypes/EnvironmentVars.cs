﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiProcesses.Common
{
    public static class EnvironmentVars
    {
        public const string ProcessTypeVar = "ProcessType";
        public const string Server = "Server";
        public const string Client = "Client";

        public static string ProcessType
        {
            get { return Environment.GetEnvironmentVariable(ProcessTypeVar); }
            set { Environment.SetEnvironmentVariable(ProcessTypeVar, value); }
        }

    }
}
