﻿using System;

namespace MultiProcesses.Common
{
    public class Data
    {
        static Random _rand = new Random();

        public Data()
        {
        }

        public Data(int id)
        {
            Id = id;

            const int minRandValue = 1000000, maxRandValue = 9999999;

            IntegerProperty1 = _rand.Next(minRandValue, maxRandValue);
            IntegerProperty2 = _rand.Next(minRandValue, maxRandValue);
            IntegerProperty3 = _rand.Next(minRandValue, maxRandValue);
            IntegerProperty4 = _rand.Next(minRandValue, maxRandValue);
            IntegerProperty5 = _rand.Next(minRandValue, maxRandValue);
            IntegerProperty6 = _rand.Next(minRandValue, maxRandValue);
            IntegerProperty7 = _rand.Next(minRandValue, maxRandValue);
            IntegerProperty8 = _rand.Next(minRandValue, maxRandValue);
            IntegerProperty9 = _rand.Next(minRandValue, maxRandValue);
            IntegerProperty10 = _rand.Next(minRandValue, maxRandValue);
        }

        public int Id { get; set; }
        public int IntegerProperty1 { get; set; }
        public int IntegerProperty2 { get; set; }
        public int IntegerProperty3 { get; set; }
        public int IntegerProperty4 { get; set; }
        public int IntegerProperty5 { get; set; }
        public int IntegerProperty6 { get; set; }
        public int IntegerProperty7 { get; set; }
        public int IntegerProperty8 { get; set; }
        public int IntegerProperty9 { get; set; }
        public int IntegerProperty10 { get; set; }
    }
}
