﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace MultiProcesses.Common
{
    public static class Logger
    {
        public static void Write(string msg)
        {
            string toLog = $"{EnvironmentVars.ProcessType}: {msg}";
            Debug.WriteLine("\t " + toLog);
            Console.WriteLine(toLog);
        }

    }
}
