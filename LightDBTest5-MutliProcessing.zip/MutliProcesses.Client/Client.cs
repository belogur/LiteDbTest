﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MultiProcesses.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MultiProcesses.Client
{
    class Client
    {
        private static string _serverPath =
            @"C:\Work\MutliProcessesValuation\MultiProcesses.Server\bin\Debug\MultiProcesses.Server.exe";

        private static int _iterationTimeout = 4000;

        // static int _dataCount = 3;


        static void Main(string[] args)
        {
            EnvironmentVars.ProcessType = EnvironmentVars.Client;
            Thread.Sleep(2000);
            try
            {
                int port;
                // port = GetFreeTcpPort();
                port = 60110;

/*
                ProcessStartInfo startInfo = new ProcessStartInfo(_serverPath, port.ToString());
                startInfo.CreateNoWindow = false;




                Log($"Client: Starting server process on port {port}");

                Process serverProcess = Process.Start(startInfo);
*/



                TestJsonSerializer();
                // TestTextReader(sender);


/*
                byte[] bytes = new byte[1024];
                int bytesRec = client.Receive(bytes);
*/

                // Release the socket.  

                // bool exited = serverProcess.WaitForExit(Timeout.Infinite);

            }

            catch (SocketException se)
            {
                Logger.Write($"SocketException : {se}");
            }
            catch (Exception e)
            {
                Logger.Write($"Unexpected exception : {e}");
            }
        }

        private static void TestJsonSerializer()
        {
            int port = 60110;

            for (int i = 3000; true; i+=500)
            {
                Console.WriteLine();

                var client = ConnectToServer(port);
                Logger.Write($"Connected to server process on {client.RemoteEndPoint}");

                Data[] dataArray = Enumerable.Range(1, i).Select(n => new Data(n)).ToArray();

                int bytesWritten = 0;
                bytesWritten = SendJsonWriter(client, dataArray);

                client.Shutdown(SocketShutdown.Send);


                // SendTextWriter(sender/*, dataArray*/);


                Logger.Write($"{i:N0} items sent, {bytesWritten:N0} bytes");

                byte[] buffer = new byte[1024];
                int bytesReceived = client.Receive(buffer);
                int serverBytes = BitConverter.ToInt32(buffer, 0);
                Logger.Write($"Server received {serverBytes:N0} bytes");

                client.Close();

/*
                if (bytesWritten >= 3 * 1024 * 1024)
                    break;
*/

                Thread.Sleep(_iterationTimeout);
            }
        }

        private static void TestTextReader(Socket sender)
        {
            for (int i = 1000; i < 9000; i += 10)
            {
                int bytesWritten = 0;

                StringBuilder builder = new StringBuilder();
                while (builder.Length < i)
                    builder.Append("123456789 ");

                var str = builder.ToString();
                SendWithTextWriter(sender, str);

                Logger.Write($"i = {i}, {str.Length} chars sent");

                byte[] buffer = new byte[1];
                int readData = sender.Receive(buffer);

                Thread.Sleep(2000);
            }
        }

        private static int SendJsonWriter(Socket sender, Data[] dataArray)
        {
            Logger.Write("Start sending data...");

            using (var networkStream = new NetworkStream(sender))
            {
                using (var dataEndMarkerStream = new NoMoreDataStream(networkStream))
                {
                    using (StreamWriter sw = new StreamWriter(dataEndMarkerStream))
                    {
                        using (JsonWriter writer = new JsonTextWriter(sw))
                        {
                            writer.CloseOutput = true;
                            JsonSerializer serializer = new JsonSerializer();
                            serializer.Converters.Add(new JavaScriptDateTimeConverter());
                            // serializer.NullValueHandling = NullValueHandling.Ignore;

                            serializer.Serialize(writer, dataArray);
                            Logger.Write($"{dataArray.Length:N0} items serialized: {dataEndMarkerStream.BytesWritten:N0} bytes sent");
                        }
                    }

                    Logger.Write($"{dataArray.Length:N0} items sent: {dataEndMarkerStream.BytesWritten:N0} bytes");
/*
                    Logger.Write($"Writing end of data byte");
                    dataEndMarkerStream.WriteByte(0);
                    dataEndMarkerStream.Flush();
*/
                    var bytesWritten = dataEndMarkerStream.BytesWritten;
                    Logger.Write($"Total {bytesWritten:N0} bytes send");
                    return bytesWritten;
                }
            }
        }

        private static void SendWithTextWriter(Socket sender, string str)
        {
            using (var networkStream = new NetworkStream(sender))
            {
                using (TextWriter sw = new StreamWriter(networkStream))
                {
                    // sw.WriteLine("123456789 12");
                    sw.WriteLine(str);
                }
            }
        }

        #region SOcket routines

        static int GetFreeTcpPort()
        {
            TcpListener tmpListener = new TcpListener(IPAddress.Loopback, 0);
            tmpListener.Start();
            int port = ((IPEndPoint)tmpListener.LocalEndpoint).Port;
            tmpListener.Stop();
            return port;
        }


        private static Socket ConnectToServer(int serverPort)
        {
            // Establish the remote endpoint for the socket.  
            // This example uses port 11000 on the local computer.  
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[0];
            IPEndPoint remoteEP = new IPEndPoint(ipAddress, serverPort);

            // Create a TCP/IP  socket.  
            Socket sender = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            sender.ReceiveTimeout = 10000;
            sender.Connect(remoteEP);
            return sender;
        }


        #endregion

    }
}
