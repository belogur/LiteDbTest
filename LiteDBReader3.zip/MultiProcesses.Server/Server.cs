﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MultiProcesses.CommonTypes;
using Newtonsoft.Json;

namespace MultiProcesses.Server
{
    class Server
    {


        /*
         *  https://stackoverflow.com/questions/34130323/deserializing-data-from-a-network-stream-hangs-using-newtonsoft-json
         *
         *
         *
         * https://stackoverflow.com/questions/8157636/can-json-net-serialize-deserialize-to-from-a-stream/22689976
         * https://github.com/JamesNK/Newtonsoft.Json/issues/645
         * https://github.com/JamesNK/Newtonsoft.Json/issues/732
         * https://stackoverflow.com/questions/6958255/what-are-some-reasons-networkstream-read-would-hang-block
         * https://github.com/JamesNK/Newtonsoft.Json/issues/732
         */
        static void Main(string[] args)
        {
            int port = Int32.Parse(args[0]);

            Console.WriteLine($"Server: Started with port {port}");

            try
            {
                Socket client = AcceptConnection(port);

                bool connected = true;
                while (connected)
                {
                                        Data[] data = ReceiveJson(client);
                                        Console.WriteLine($"Data received: '{data.Length}, from {data[0].Id} to {data.Last().Id}'");

/*                    var str = ReceiveStreamReader(client);
                    Console.WriteLine($"Data received: '{str}'");*/

                    client.Send(new byte[] {(byte) 1});
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                Console.WriteLine("Press any key to exit...");
                Console.ReadKey();
            }

            Console.WriteLine("\nCompleted successfully");
        }

        public static Socket AcceptConnection(int port)
        {
            // Establish the local endpoint for the socket.  
            // Dns.GetHostName returns the name of the   
            // host running the application.  
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[0];
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, port);

            // Create a TCP/IP socket.  
            Socket listener = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            // Bind the socket to the local endpoint and   
            // listen for incoming connections.  
            listener.Bind(localEndPoint);
            listener.Listen(10);

            Console.WriteLine($"Waiting for a connection on port {port}");
            // Program is suspended while waiting for an incoming connection.  
            Socket client = listener.Accept();

            Console.WriteLine($"Accepted client on {client.RemoteEndPoint}");

            return client;
        }

        private static Data[] ReceiveJson(Socket client)
        {
            // An incoming connection needs to be processed.  
            // https://docs.microsoft.com/en-us/dotnet/api/system.net.sockets.networkstream?redirectedfrom=MSDN&view=netframework-4.8


            using (var networkStream = new NetworkStream(client))
            {
                using (var streamReader = new StreamReader(networkStream))
                using (var jsonTextReader = new JsonTextReader(streamReader))
                {
                    var serializer = new JsonSerializer();
                    var data = serializer.Deserialize<Data[]>(jsonTextReader);
                    return data;
                }
            }
        }

        private static string ReceiveStreamReader(Socket client)
        {
            StringBuilder builder = new StringBuilder();
            // An incoming connection needs to be processed.  
            // https://docs.microsoft.com/en-us/dotnet/api/system.net.sockets.networkstream?redirectedfrom=MSDN&view=netframework-4.8
            using (var networkStream = new NetworkStream(client))
            {
                using (var sr = new StreamReader(networkStream))
                {
                    char[] buffer = new char[10];
                    int bytesRead;
                    while ((bytesRead = sr.Read(buffer, 0, buffer.Length)) != 0)
                    {
                        builder.Append(buffer, 0, bytesRead);
                        buffer = new char[10];
                        var da = networkStream.DataAvailable;
                    }

                    var str = builder.ToString();
                    return str;
                }
            }
        }

        private static string ReceiveData3(Socket client)
        {
            StringBuilder builder = new StringBuilder();
            // An incoming connection needs to be processed.  
            // https://docs.microsoft.com/en-us/dotnet/api/system.net.sockets.networkstream?redirectedfrom=MSDN&view=netframework-4.8
            using (var networkStream = new NetworkStream(client))
            {
                byte[] buffer = new byte[10];
                int bytesRead;
                while ((bytesRead = networkStream.Read(buffer, 0, buffer.Length)) != 0)
                {
                    string stringData = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                    builder.Append(stringData);
                    buffer = new byte[10];
                }

                var str = builder.ToString();
                return str;
            }
        }

        private static void SendResponse(Socket client)
        {
            // Echo the data back to the client.  
            byte[] msg = Encoding.ASCII.GetBytes(_data);

            client.Send(msg);
            client.Shutdown(SocketShutdown.Both);
            client.Close();
        }

        public static void ReceiveData(int port)
        {
            



        }


        /////////////////////////////////////////////////////////////////////

        // Incoming data from the client.  
        public static string _data = null;

        public static void StartListening()
        {
            // Data buffer for incoming data.  
            byte[] bytes = new Byte[1024];

            // Establish the local endpoint for the socket.  
            // Dns.GetHostName returns the name of the   
            // host running the application.  
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[0];
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 11000);

            // Create a TCP/IP socket.  
            Socket listener = new Socket(ipAddress.AddressFamily,
                SocketType.Stream, ProtocolType.Tcp);

            // Bind the socket to the local endpoint and   
            // listen for incoming connections.  
            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(10);

                // Start listening for connections.  
                while (true)
                {
                    Console.WriteLine("Waiting for a connection...");
                    // Program is suspended while waiting for an incoming connection.  
                    Socket handler = listener.Accept();
                    _data = null;

                    // An incoming connection needs to be processed.  
                    while (true)
                    {
                        int bytesRec = handler.Receive(bytes);
                        _data += Encoding.ASCII.GetString(bytes, 0, bytesRec);
                        if (_data.IndexOf("<EOF>") > -1)
                        {
                            break;
                        }
                    }

                    // Show the data on the console.  
                    Console.WriteLine("Text received : {0}", _data);

                    // Echo the data back to the client.  
                    byte[] msg = Encoding.ASCII.GetBytes(_data);

                    handler.Send(msg);
                    handler.Shutdown(SocketShutdown.Both);
                    handler.Close();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("\nPress ENTER to continue...");
            Console.Read();

        }
    }
}
