﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MultiProcesses.CommonTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MultiProcesses.Client
{
    class Client
    {
        private static string _serverPath =
            @"C:\Work\MutliProcessesValuation\MultiProcesses.Server\bin\Debug\MultiProcesses.Server.exe";

        // static int _dataCount = 3;

        static void Main(string[] args)
        {
            try
            {
                int port;
                // port = GetFreeTcpPort();
                port = 60110;

/*
                ProcessStartInfo startInfo = new ProcessStartInfo(_serverPath, port.ToString());
                startInfo.CreateNoWindow = false;

                Console.WriteLine($"Client: Starting server process on port {port}");

                Process serverProcess = Process.Start(startInfo);
*/


                var sender = ConnectToServer(port);
                Console.WriteLine("Connected to server process on {0}", sender.RemoteEndPoint);

                for (int i = 6; i < 100; i++)
                {
                    Data[] dataArray = Enumerable.Range(1, i).Select(n => new Data(n)).ToArray();

                    int bytesWritten = 0;
                    bytesWritten = SendJsonWriter(sender, dataArray);
                    
                    
                    // SendTextWriter(sender/*, dataArray*/);


                    Console.WriteLine($"{i} items sent, {bytesWritten} bytes");

                    byte[] buffer = new byte[1];
                    int readData = sender.Receive(buffer);

                    Thread.Sleep(2000);

                }


                byte[] bytes = new byte[1024];
                int bytesRec = sender.Receive(bytes);

                // Release the socket.  
                sender.Shutdown(SocketShutdown.Both);
                sender.Close();

                // bool exited = serverProcess.WaitForExit(Timeout.Infinite);

            }

            catch (SocketException se)
            {
                Console.WriteLine("SocketException : {0}", se.ToString());
            }
            catch (Exception e)
            {
                Console.WriteLine("Unexpected exception : {0}", e.ToString());
            }
        }

        static int GetFreeTcpPort()
        {
            TcpListener tmpListener = new TcpListener(IPAddress.Loopback, 0);
            tmpListener.Start();
            int port = ((IPEndPoint)tmpListener.LocalEndpoint).Port;
            tmpListener.Stop();
            return port;
        }

        private static Socket ConnectToServer(int serverPort)
        {
            // Establish the remote endpoint for the socket.  
            // This example uses port 11000 on the local computer.  
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[0];
            IPEndPoint remoteEP = new IPEndPoint(ipAddress, serverPort);

            // Create a TCP/IP  socket.  
            Socket sender = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            sender.Connect(remoteEP);
            return sender;
        }

        private static int SendJsonWriter(Socket sender, Data[] dataArray)
        {
            Console.WriteLine("Start sending data...");

            using (var networkStream = new NetworkStream(sender))
            {
                using (var streamCounter = new StreamCounter(networkStream))
                {
                    using (StreamWriter sw = new StreamWriter(streamCounter))
                    {
                        using (JsonWriter writer = new JsonTextWriter(sw))
                        {
                            writer.CloseOutput = true;
                            JsonSerializer serializer = new JsonSerializer();
                            serializer.Converters.Add(new JavaScriptDateTimeConverter());
                            // serializer.NullValueHandling = NullValueHandling.Ignore;

                            serializer.Serialize(writer, dataArray);
                        }

                    }

                    networkStream.Flush();

                    Console.WriteLine("Sending data completed...");
                    return streamCounter.BytesWritten;
                }
            }
        }

        private static void SendTextWriter(Socket sender)
        {
            Console.WriteLine("Start sending data...");

            using (var networkStream = new NetworkStream(sender))
            {
                using (TextWriter sw = new StreamWriter(networkStream))
                {
                    sw.WriteLine("123456789 12");
                    sw.Write((char)26);
                    sw.Write((char)0);
                }
            }

            Console.WriteLine("Sending data completed...");
        }
    }

    class StreamCounter : Stream
    {
        private Stream _stream;

        public int _bytesRead;
        public int _bytesWritten;

        public StreamCounter(Stream stream)
        {
            _stream = stream;
        }

        public int BytesRead => _bytesRead;

        public int BytesWritten => _bytesWritten;

        public override void Flush()
        {
            _stream.Flush();
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            return _stream.Seek(offset, origin);
        }

        public override void SetLength(long value)
        {
            _stream.SetLength(value);
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            int bytesRead = _stream.Read(buffer, offset, count);
            _bytesRead += bytesRead;
            return bytesRead;
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            _bytesWritten += count;
            _stream.Write(buffer, offset, count);
        }

        public override bool CanRead
        {
            get { return _stream.CanRead; }
        }

        public override bool CanSeek
        {
            get { return _stream.CanSeek; }
        }
        public override bool CanWrite
        {
            get { return _stream.CanWrite; }
        }

        public override long Length
        {
            get { return _stream.Length; }
        }

        public override long Position
        {
            get { return _stream.Position; }
            set { _stream.Position = value; }
        }
    }
}
